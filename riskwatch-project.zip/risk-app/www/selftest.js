/* مجموعه تست دقت: تیترهای واقعی و ساختگی با پاسخ درست.
   هر بار که قانون‌ها عوض می‌شوند باید همه موارد قبول شوند. */
(function (root) {
'use strict';
const C = (id, source, group, title, body, expect) => ({ id, source, group, title, body: body || '', expect });
const CASES = [
  // ---- نشانه‌های واقعی: باید گرفته شوند ----
  C('embassy-ordered-departure', 'رویترز', 'reuters', 'US embassy ordered departure of non-emergency staff as strike on Iran looms', '', { ev: [['embassy', 'A']] }),
  C('iran-airspace-closed', 'رویترز', 'reuters', 'Iran closes its entire airspace until further notice', '', { ev: [['airspace', 'A']] }),
  C('tse-halted', 'رویترز', 'reuters', 'Tehran Stock Exchange halted as Israeli strikes hit Iranian capital', '', { ev: [['civil', 'A']] }),
  C('schools-closed-security', 'AP', 'ap', 'Iran: schools and universities closed until further notice, Supreme National Security Council says after attack', '', { ev: [['civil', 'A']] }),
  C('rosatom-evac', 'رویترز', 'reuters', "Russia evacuates Rosatom staff from Iran's Bushehr nuclear plant", '', { ev: [['military', 'B']] }),
  C('axios-drawdown', 'Axios', 'axios', 'US is reducing staffing at 4 Middle East embassies over increased threats from Iran', '', { ev: [['embassy', 'B']], noEase: true }),
  C('airlines-suspend', 'الجزیره', 'aljazeera', 'Airlines suspend flights to Tehran as US military buildup near Iran continues', '', { ev: [['airspace', 'B']] }),
  C('mobile-cut', 'BBC', 'bbc', 'Mobile phone services cut across Tehran', '', { ev: [['civil', 'B']] }),
  C('imminent', 'رویترز', 'reuters', 'Western official says US strike on Iran imminent', '', { ev: [['military', 'B']] }),
  C('hormuz-tanker', 'رویترز', 'reuters', 'Tanker attacked in Strait of Hormuz, UKMTO issues advisory', '', { ev: [['markets', 'B']] }),
  C('home-front', 'AP', 'ap', 'Israel Home Front Command issues new restrictions on gatherings amid Iran threat', '', { ev: [['military', 'B']] }),
  C('qatar-airspace', 'رویترز', 'reuters', 'Qatar closes airspace as Iran tensions mount', '', { ev: [['airspace', 'B']], noEv: [['airspace', 'A']] }),
  C('carrier', 'رویترز', 'reuters', 'US sends aircraft carrier to the Gulf as tensions with Iran escalate', '', { ev: [['military', 'C']] }),
  C('iaea', 'رویترز', 'reuters', 'IAEA board report says Iran enriched uranium stockpile growing', '', { ev: [['news', 'C']] }),
  C('embassy-reopen', 'رویترز', 'reuters', 'French embassy in Tehran reopens after talks ease tensions', '', { ev: [['embassy', 'ease']] }),
  // ---- باید نادیده گرفته شوند ----
  C('ukraine-ceasefire', 'AP', 'ap', 'Melania Trump brokers a ceasefire deal in Russian-occupied Ukrainian city', '', { none: true }),
  C('lng', 'رویترز', 'reuters', 'Top LNG exporter QatarEnergy in talks to buy US LNG from Woodside', '', { none: true }),
  C('schools-pollution', 'ایرنا', 'irna', 'Schools closed in Tehran until further notice due to air pollution', '', { none: true }),
  C('schools-sandstorm', 'AP', 'ap', 'Schools and offices closed in Tehran after sandstorm blankets Iran', '', { none: true }),
  C('what-if', 'tabloid', 'x', 'What happens if the US strikes Tehran? Experts warn', 'If the US bombed Tehran, explosions could hit the city.', { none: true, attack: 'reject' }),
  C('air-defence-drill', 'رویترز', 'reuters', 'Iran holds air defence drill near Isfahan', 'The drill was planned months ago.', { none: true }),
  C('irna-commentary', 'ایرنا', 'irna', 'محاسبات آمریکا درباره اهداف جنگ ایران اشتباه بود', '', { none: true }),
  C('rial', 'رویترز', 'reuters', 'Iran rial hits record low against dollar', '', { none: true }),
  C('missile-test', 'رویترز', 'reuters', 'Iran conducts missile test in Semnan province', '', { none: true, attack: 'reject' }),
  // ---- حمله: تشخیص حمله نظامی، حادثه، و مقیاس ----
  C('strike-tehran', 'رویترز', 'reuters', 'Explosions heard in Tehran, witnesses report air strikes', 'Witnesses told Reuters that explosions struck Tehran today. Air strikes hit sites in the capital.', { attack: 'ok', scale: 'limited' }),
  C('strike-wide', 'رویترز', 'reuters', 'US and Israel launch strikes on Iran, explosions reported in Tehran, Isfahan and Qom', 'Explosions were reported today in Tehran, Isfahan and Qom as strikes hit several cities.', { attack: 'ok', scale: 'wide' }),
  C('strike-wide-fa', 'بی‌بی‌سی', 'bbc', 'آغاز حمله هوایی گسترده به چند شهر ایران؛ انفجار در تهران و اصفهان', 'امروز صدای انفجار در تهران و اصفهان شنیده شد. حمله هوایی چند شهر را هدف قرار داد.', { attack: 'ok', scale: 'wide' }),
  C('gas-en', 'رویترز', 'reuters', 'Gas explosion hits residential building in Tehran, two injured', 'A gas explosion today in Tehran injured two people.', { attack: 'reject' }),
  C('gas-fa', 'ایرنا', 'irna', 'انفجار گاز در یک ساختمان مسکونی در تهران؛ دو نفر مجروح شدند', 'انفجار گاز امروز در تهران رخ داد.', { attack: 'reject' }),
  C('fireworks', 'AP', 'ap', 'Fireworks explosion injures dozens in Isfahan', 'The blast today in Isfahan injured dozens.', { attack: 'reject' }),
  C('unknown-blast', 'رویترز', 'reuters', 'Explosion heard in Shiraz, cause unknown', 'Residents in Shiraz reported an explosion today.', { attack: 'reject' }),
  C('sonic-boom', 'AP', 'ap', 'Sonic boom heard in Tehran, officials say', 'A loud explosion-like noise was heard in Tehran today.', { attack: 'reject' }),
  C('limited-drone', 'رویترز', 'reuters', 'Israeli drone strike hits vehicle near Kermanshah, one killed', 'An Israeli drone strike hit a vehicle near Kermanshah today, killing one person.', { attack: 'ok', scale: 'limited' }),
  C('anniversary', 'AP', 'ap', 'Iranians mark anniversary of the 12-day war with strikes on Tehran remembered', 'On the anniversary of last year strikes in Tehran, ceremonies were held.', { attack: 'reject' }),
];

function run(E) {
  const now = Date.now();
  const fails = [];
  for (const c of CASES) {
    const it = { title: c.title, body: c.body, source: c.source, group: c.group, ts: now - 5 * 60000, link: 'st:' + c.id, fullText: !!c.body };
    const evs = E.classify(it, now);
    const has = (ind, tier) => evs.some(e => e.ind === ind && e.tier === tier);
    const x = c.expect;
    (x.ev || []).forEach(([ind, tier]) => { if (!has(ind, tier)) fails.push(c.id + ': باید ' + ind + '/' + tier + ' می‌گرفت. گرفت: ' + (evs.map(e => e.ind + '/' + e.tier).join(', ') || 'هیچ')); });
    (x.noEv || []).forEach(([ind, tier]) => { if (has(ind, tier)) fails.push(c.id + ': نباید ' + ind + '/' + tier + ' می‌گرفت'); });
    if (x.noEase && evs.some(e => e.tier === 'ease')) fails.push(c.id + ': نباید «کاهش تنش» حساب می‌شد');
    if (x.none && evs.some(e => e.pts > 0 && e.tier !== 'ease')) fails.push(c.id + ': نباید نشانه می‌گرفت. گرفت: ' + evs.map(e => e.ind + '/' + e.tier).join(', '));
    if (x.attack) {
      const la = E.looksLikeAttack(it);
      const v = la ? E.verifyAttack(it, now) : { ok: false, reason: 'looksLikeAttack=false' };
      if (x.attack === 'ok' && !v.ok) fails.push(c.id + ': باید حمله تشخیص داده می‌شد. دلیل رد: ' + v.reason);
      if (x.attack === 'reject' && v.ok) fails.push(c.id + ': نباید حمله حساب می‌شد (مقیاس ' + v.scale + ')');
      if (x.scale && v.ok && v.scale !== x.scale) fails.push(c.id + ': مقیاس باید ' + x.scale + ' می‌بود، شد ' + v.scale);
    }
  }
  return { total: CASES.length, passed: CASES.length - new Set(fails.map(f => f.split(':')[0])).size, failures: fails };
}
const api = { CASES, run };
if (typeof module !== 'undefined' && module.exports) module.exports = api;
root.SelfTest = api;
})(typeof window !== 'undefined' ? window : globalThis);
