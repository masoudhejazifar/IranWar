package ir.masoud.riskwatch;

import android.graphics.Bitmap;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;

/** رسم ویجت: نیم‌دایره قطعه‌قطعه با درجه‌بندی و نور، هم‌سبک اپ (چپ سبز، راست قرمز) */
final class Gauge {
    private Gauge() { }

    static String fa(Object v) {
        String s = String.valueOf(v);
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            b.append(c >= '0' && c <= '9' ? (char) ('۰' + (c - '0')) : c);
        }
        return b.toString();
    }

    static int levelColor(int score) {
        if (score < 0) return 0xFF7F93A8;
        if (score <= 25) return 0xFF19E68C;
        if (score <= 50) return 0xFFFFB020;
        if (score <= 75) return 0xFFFF7A1A;
        return 0xFFFF2D3D;
    }

    private static final float[] STOP_F = {0f, 0.28f, 0.5f, 0.72f, 1f};
    private static final int[][] STOP_C = {{25, 230, 140}, {155, 226, 42}, {255, 196, 0}, {255, 122, 26}, {255, 45, 61}};

    static int colorAt(float f) {
        for (int i = 1; i < STOP_F.length; i++) {
            if (f <= STOP_F[i]) {
                float t = (f - STOP_F[i - 1]) / (STOP_F[i] - STOP_F[i - 1]);
                int r = Math.round(STOP_C[i - 1][0] + (STOP_C[i][0] - STOP_C[i - 1][0]) * t);
                int g = Math.round(STOP_C[i - 1][1] + (STOP_C[i][1] - STOP_C[i - 1][1]) * t);
                int b = Math.round(STOP_C[i - 1][2] + (STOP_C[i][2] - STOP_C[i - 1][2]) * t);
                return 0xFF000000 | (r << 16) | (g << 8) | b;
            }
        }
        return 0xFFFF2D3D;
    }

    static Bitmap draw(int score, String levelName, String timeText, boolean stale, String banner) {
        final int W = 640, H = 300;
        Bitmap bm = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bm);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        int lvl = levelColor(score);

        // پس‌زمینه و قاب
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0, 0, 0, H, 0xFF0E1A28, 0xFF060B12, Shader.TileMode.CLAMP));
        RectF box = new RectF(2, 2, W - 2, H - 2);
        cv.drawRoundRect(box, 30, 30, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2);
        p.setColor(0x5538D6FF);
        cv.drawRoundRect(box, 30, 30, p);
        // گوشه‌های برجسته
        p.setStrokeWidth(5);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setColor(lvl);
        Path c1 = new Path(); c1.moveTo(10, 46); c1.lineTo(10, 34); c1.quadTo(10, 10, 34, 10); c1.lineTo(46, 10);
        Path c2 = new Path(); c2.moveTo(W - 10, H - 46); c2.lineTo(W - 10, H - 34); c2.quadTo(W - 10, H - 10, W - 34, H - 10); c2.lineTo(W - 46, H - 10);
        cv.drawPath(c1, p); cv.drawPath(c2, p);

        // نیم‌دایره قطعه‌قطعه
        final float cx = 196, cy = 240, r = 124, thick = 30;
        final int N = 36;
        final float seg = 180f / N, gap = 1.6f;
        RectF oval = new RectF(cx - r, cy - r, cx + r, cy + r);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.BUTT);
        p.setStrokeWidth(thick);
        // نور قطعه‌های روشن
        Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        glow.setStyle(Paint.Style.STROKE);
        glow.setStrokeWidth(thick + 8);
        glow.setMaskFilter(new BlurMaskFilter(14, BlurMaskFilter.Blur.NORMAL));
        for (int i = 0; i < N; i++) {
            float f = (i + 0.5f) / N;
            boolean lit = score >= 0 && f * 100f <= score;
            float start = 180f + i * seg + gap / 2;
            if (lit) {
                glow.setColor((colorAt(f) & 0x00FFFFFF) | 0x66000000);
                cv.drawArc(oval, start, seg - gap, false, glow);
            }
        }
        for (int i = 0; i < N; i++) {
            float f = (i + 0.5f) / N;
            boolean lit = score >= 0 && f * 100f <= score;
            p.setColor(lit ? colorAt(f) : ((colorAt(f) & 0x00FFFFFF) | 0x30000000));
            cv.drawArc(oval, 180f + i * seg + gap / 2, seg - gap, false, p);
        }

        // درجه‌ها
        p.setStrokeCap(Paint.Cap.BUTT);
        for (int k = 0; k <= 20; k++) {
            boolean major = k % 5 == 0;
            double th = Math.PI * (1.0 - k / 20.0);
            float r0 = r + thick / 2 + 8, r1 = r0 + (major ? 14 : 7);
            p.setStrokeWidth(major ? 3f : 1.6f);
            p.setColor(major ? 0xDDE8F0F8 : 0x667F93A8);
            cv.drawLine((float) (cx + r0 * Math.cos(th)), (float) (cy - r0 * Math.sin(th)),
                    (float) (cx + r1 * Math.cos(th)), (float) (cy - r1 * Math.sin(th)), p);
        }

        // عقربه
        if (score >= 0) {
            double th = Math.PI * (1.0 - score / 100.0);
            float len = r - thick / 2 - 6;
            float tx = (float) (cx + len * Math.cos(th)), ty = (float) (cy - len * Math.sin(th));
            float nx = (float) Math.sin(th), ny = (float) Math.cos(th);   // عمود بر عقربه
            Path needle = new Path();
            needle.moveTo(cx + nx * 6, cy + ny * 6);
            needle.lineTo(tx, ty);
            needle.lineTo(cx - nx * 6, cy - ny * 6);
            needle.close();
            Paint ng = new Paint(Paint.ANTI_ALIAS_FLAG);
            ng.setColor(0x88FFFFFF);
            ng.setMaskFilter(new BlurMaskFilter(8, BlurMaskFilter.Blur.NORMAL));
            cv.drawPath(needle, ng);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFFFFFFFF);
            cv.drawPath(needle, p);
        }
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF071019);
        cv.drawCircle(cx, cy, 19, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(3);
        p.setColor(0xFFFFFFFF);
        cv.drawCircle(cx, cy, 19, p);
        p.setStyle(Paint.Style.FILL);
        cv.drawCircle(cx, cy, 6, p);

        // متن‌ها
        final float tcx = 486;
        p.setTextAlign(Paint.Align.CENTER);
        p.setStyle(Paint.Style.FILL);
        p.setTypeface(Typeface.MONOSPACE);
        p.setTextSize(19);
        p.setColor(0xFF7F93A8);
        p.setLetterSpacing(0.22f);
        cv.drawText("THREAT LEVEL", tcx, 50, p);
        p.setLetterSpacing(0f);
        p.setTypeface(Typeface.DEFAULT_BOLD);

        String big = score >= 0 ? fa(score) : "—";
        Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        bg.setTextAlign(Paint.Align.CENTER);
        bg.setTypeface(Typeface.DEFAULT_BOLD);
        bg.setTextSize(122);
        bg.setColor((lvl & 0x00FFFFFF) | 0x99000000);
        bg.setMaskFilter(new BlurMaskFilter(18, BlurMaskFilter.Blur.NORMAL));
        cv.drawText(big, tcx, 160, bg);
        p.setTextSize(122);
        p.setColor(lvl);
        cv.drawText(big, tcx, 160, p);

        // برچسب سطح
        String label = (banner != null && !banner.isEmpty()) ? banner : levelName;
        p.setTextSize(40);
        float tw = p.measureText(label);
        float bw = Math.max(tw + 56, 190), bh = 58;
        RectF pill = new RectF(tcx - bw / 2, 180, tcx + bw / 2, 180 + bh);
        p.setStyle(Paint.Style.FILL);
        p.setColor((lvl & 0x00FFFFFF) | 0x26000000);
        cv.drawRoundRect(pill, 8, 8, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2.5f);
        p.setColor(lvl);
        cv.drawRoundRect(pill, 8, 8, p);
        p.setStyle(Paint.Style.FILL);
        cv.drawText(label, tcx, 180 + 42, p);

        p.setTypeface(Typeface.DEFAULT);
        p.setFakeBoldText(false);
        p.setTextSize(24);
        p.setColor(stale ? 0xFFFF6B6B : 0xFF7F93A8);
        cv.drawText(stale ? "داده قدیمی • " + timeText : "آخرین بررسی " + timeText, tcx, 270, p);
        return bm;
    }
}
